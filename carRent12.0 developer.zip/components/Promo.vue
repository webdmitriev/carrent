<template>
  <section class="promo">
    <div class="container">
      <h1 class="title">My SSR Blog Whith Nuxt.Js</h1>
      <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Consequuntur magni porro neque doloremque temporibus beatae laboriosam, sapiente aliquam rem nam quaerat animi delectus repellat vel eum error ea laborum iure.</p>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style lang="scss">
.promo {
  text-align: center;
  p {
    color: #999999;
  }
}
</style>
