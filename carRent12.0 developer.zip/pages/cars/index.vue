<template>
  <section class="all-cars">
    <div class="container">
      <h2>preview-cars</h2>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style lang="scss">
$white: #fff;
$black: #333;

@media (max-width: 1366px) {
}

@media (max-width: 1199px) {
}

@media (max-width: 991px) {
}

@media (max-width: 768px) {
}

@media (max-width: 576px) {
}

@media (max-width: 400px) {
}
</style>
