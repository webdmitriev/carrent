<template>
  <section class="user">
    <div class="container">
      <h2>Template Default</h2>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
@media (max-width: 1366px) {
}

@media (max-width: 1199px) {
}

@media (max-width: 991px) {
}

@media (max-width: 768px) {
}

@media (max-width: 576px) {
}

@media (max-width: 400px) {
}
</style>
