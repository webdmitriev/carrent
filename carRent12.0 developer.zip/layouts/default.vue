<template>
  <div class="wrapper">
    <nuxt />
  </div>
</template>

<script>
export default {};
</script>
